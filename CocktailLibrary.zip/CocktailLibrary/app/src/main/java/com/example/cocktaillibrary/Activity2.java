package com.example.cocktaillibrary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {
    TextView textCocktailDescription;
    private Button btnToRecipe;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        Intent myCallerIntent = getIntent();
        Bundle myBundle = myCallerIntent.getExtras();
        String strPicture = myBundle.getString("picture");
        String strDescription = myBundle.getString("description");
        String strIngredients = myBundle.getString("ingredients");
        String strRecipe = myBundle.getString("recipe");



        textCocktailDescription = (TextView) findViewById(R.id.textCocktailDescription);
        textCocktailDescription.setText(strDescription);



        // ImageView imageView =(ImageView) findViewById(R.id.imageView);
        // Image: Picture

        //String imageName = "manhattan";
        //String imageName = toString(strPicture);
        System.out.println("Activity2 pict: " + strPicture);

        //int res = getResources().getIdentifier(imageName, "drawable", this.getPackageName());
        int res = getResources().getIdentifier(strPicture, "drawable", this.getPackageName());
        ImageView imageView= (ImageView)findViewById(R.id.imageView);
        imageView.setImageResource(res);


        btnToRecipe = (Button) findViewById(R.id.btnToRecipe);
        btnToRecipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String intentStrIngred = strIngredients;
                String intentStrRecipe = strRecipe;

                Intent intent = new Intent(Activity2.this, Activity3.class);
                Bundle myDataBundle = new Bundle();
                myDataBundle.putString("ingredients", intentStrIngred);
                myDataBundle.putString("recipe", intentStrRecipe);

                intent.putExtras(myDataBundle);
                startActivityForResult(intent, 101);

                //openActivity2();
            }
        });

    }

}