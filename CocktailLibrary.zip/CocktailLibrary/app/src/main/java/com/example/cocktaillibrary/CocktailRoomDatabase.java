package com.example.cocktaillibrary;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static java.time.chrono.IsoChronology.INSTANCE;

@Database(entities = {Cocktail.class}, version = 1, exportSchema = false)
public abstract class CocktailRoomDatabase extends RoomDatabase {

    public abstract CocktailDao cocktailDao();

    private static volatile CocktailRoomDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);
    public static ExecutorService getDatabaseWriteExecutor() { return databaseWriteExecutor; }

    static CocktailRoomDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (CocktailRoomDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            CocktailRoomDatabase.class, "cocktail_database")
                            //.addCallback(sRoomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static RoomDatabase.Callback sRoomDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);

            // Usuwa dane przy uruchomieniu
            databaseWriteExecutor.execute(() -> {
                CocktailDao dao = INSTANCE.cocktailDao();
                dao.deleteAll();
                System.out.println("TEEEEST dodawania");
                Cocktail cocktail = new Cocktail("drink", "Rum", "mojito", "Mojito description", "Ingredients", "Recipe:");
                dao.insert(cocktail);
                cocktail = new Cocktail("TEEETS1", "Rum2", "mojito2", "Mojito description2", "Ingredients2", "Recipe2:");
                dao.insert(cocktail);

            });
    }
};
}

