package com.example.cocktaillibrary;
import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

class CocktailRepository {

    private CocktailDao mCocktailDao;
    private LiveData<List<Cocktail>> mAllCocktails;


    CocktailRepository(Application application) {
        CocktailRoomDatabase db = CocktailRoomDatabase.getDatabase(application);
        mCocktailDao = db.cocktailDao();
        mAllCocktails = mCocktailDao.getAlphabetizedCocktails();
    }

    LiveData<List<Cocktail>> getAllCocktails() {
        return mAllCocktails;
    }

    void insert(Cocktail cocktail) {
        CocktailRoomDatabase.databaseWriteExecutor.execute(() -> {
            mCocktailDao.insert(cocktail);
        });
    }
}
