package com.example.cocktaillibrary;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import java.util.List;

public class CocktailViewModel extends AndroidViewModel {

    private CocktailRepository mRepository;

    private final LiveData<List<Cocktail>> mAllCocktails;

    public CocktailViewModel (Application application) {
        super(application);
        mRepository = new CocktailRepository(application);
        mAllCocktails = mRepository.getAllCocktails();
    }

    LiveData<List<Cocktail>> getAllCocktails() { return mAllCocktails; }

    public void insert(Cocktail cocktail) { mRepository.insert(cocktail); }
}