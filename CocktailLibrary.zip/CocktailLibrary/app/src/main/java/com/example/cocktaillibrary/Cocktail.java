package com.example.cocktaillibrary;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;

@Entity(tableName = "cocktail_table")
public class Cocktail {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "Cocktail Name")
    private String mName;

    @ColumnInfo(name = "Cocktail Base")
    private String mBase;
    @ColumnInfo(name = "Cocktail Picture")
    private String mPicture;
    @ColumnInfo(name = "Cocktail Description")
    private String mDescription;
    @ColumnInfo(name = "Cocktail Ingredients")
    private String mIngredients;
    @ColumnInfo(name = "Cocktail Recipe")
    private String mRecipe;

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //      ?????????????????????????????????????????????????????????????????????????????????????????????????????????????????
    public Cocktail(@NonNull String name, String base, String picture, String description, String ingredients, String recipe) {
        this.mName = name;
        this.mBase = base;
        this.mPicture = picture;
        this.mDescription = description;
        this.mIngredients = ingredients;
        this.mRecipe = recipe;
    }

    @NonNull
    public String getName() { return this.mName; }
    public String getBase() { return this.mBase; }
    public String getPicture() { return this.mPicture; }
    public String getDescription() { return this.mDescription; }
    public String getIngredients() { return this.mIngredients; }
    public String getRecipe() { return this.mRecipe; }

}



