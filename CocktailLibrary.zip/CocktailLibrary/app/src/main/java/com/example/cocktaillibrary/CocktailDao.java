package com.example.cocktaillibrary;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface CocktailDao {
    @Query("SELECT * FROM cocktail_table ORDER BY `Cocktail Name` ASC")
    LiveData<List<Cocktail>> getAlphabetizedCocktails();

    @Insert(onConflict = OnConflictStrategy.REPLACE)    // bylo ignore
    void insert(Cocktail cocktail);

    @Query("DELETE FROM cocktail_table")
    void deleteAll();
}
