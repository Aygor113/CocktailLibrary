package com.example.cocktaillibrary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class Activity3 extends AppCompatActivity {

    TextView textCocktailIngredients;
    TextView textCocktailRecipe;

    //private Button btnToRecipe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        Intent myCallerIntent = getIntent();
        Bundle myBundle = myCallerIntent.getExtras();
        String strIngredients = myBundle.getString("ingredients");
        String strRecipe = myBundle.getString("recipe");


        textCocktailIngredients = (TextView) findViewById(R.id.textCocktailIngredients);
        textCocktailRecipe = (TextView) findViewById(R.id.textCocktailRecipe);

        textCocktailIngredients.setText(strIngredients);
        textCocktailRecipe.setText(strRecipe);
    }
}