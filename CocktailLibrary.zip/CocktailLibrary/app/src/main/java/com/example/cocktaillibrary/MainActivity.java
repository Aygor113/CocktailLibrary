package com.example.cocktaillibrary;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

import static java.time.chrono.IsoChronology.INSTANCE;

public class MainActivity extends AppCompatActivity {
    private static int SPLASH_TIME_OUT = 4000;
    public static final String EXTRA_REPLY = "com.example.android.wordlistsql.REPLY";

    private Button btnCocktail1;
    private Button btnCocktail2;
    private Button btnCocktail3;
    private Button btnCocktail4;

    TextView textCocktailName1;
    TextView textCocktailName2;
    TextView textCocktailName3;
    TextView textCocktailName4;

    TextView textCocktailBase1;
    TextView textCocktailBase2;
    TextView textCocktailBase3;
    TextView textCocktailBase4;

    private CocktailViewModel mCocktailViewModel;


    public String strPicture;
    public String strDescription;
    public String strIngredients;
    public String strRecipe;


    // Listy przechowujace skladowe do poszczegolnych koktajli
    ArrayList<String> cubalibre = new ArrayList<String>();
    ArrayList<String> manhattan = new ArrayList<String>();
    ArrayList<String> mojito = new ArrayList<String>();
    ArrayList<String> pinacolada = new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Welcome Screen
        Intent splashIntent = new Intent(this, SplashActivity.class);
        startActivity(splashIntent);

        int current_version = 2;            // ZMIENIAC WERSJE PRZY KONFIGURACJI
        SharedPreferences sharedPref = getSharedPreferences("db", Context.MODE_PRIVATE);
        int saved_version = sharedPref.getInt("version", -1);
        if(saved_version != current_version)
        {
            //todo
            CocktailRoomDatabase db = CocktailRoomDatabase.getDatabase(this);

            db.getDatabaseWriteExecutor().execute(() -> {                // Populate the database in the background.
                CocktailDao dao = db.cocktailDao();
                dao.deleteAll();
                System.out.println("TEEEEST dodawania");
                // CUBA LIBRE
                Cocktail cocktail = new Cocktail("Cuba Libre", "Rum", "cubalibre", "The cocktail originated in the early 20th century in Cuba" +
                        " It subsequently became popular across Cuba, the United States, and other countries." +
                        " Its simple recipe and inexpensive, ubiquitous ingredients have made it one of the world's most-popular alcoholic drinks.",
                        "Ingredients:\n" + "- 12 cl cola\n" +
                                   " - 5 cl white rum\n" +
                                   " - 1 cl Fresh lime juice",
                        "Recipe: \n" +
                                "1. To create this legendary cocktail, fill a glass with lots of ice\n" +
                                "2. Squeeze and drop 2 lime wedges into the glass, coating the ice well with the juices (it all makes a difference)\n" +
                                "3. Pour in the Bacardi Oro, top up with chilled cola and stir gently");
                dao.insert(cocktail);
                // MANHATTAN
                cocktail = new Cocktail("Manhattan", "Whisky", "manhattan", "The Manhattan is a classic cocktail of choice for whiskey-lovers. " +
                        "This delightful mix of rye or bourbon whiskey, sweet vermouth, and bitters has been adored for hundreds of" +
                        " years because of its subtle bitterness and herbal undertones.",
                        "Ingredients:\n" +
                                "- 5 cl Rye whiskey\n" +
                                "- 2 cl Sweet red vermouth\n" +
                                " - Dash Angostura bitters\n" +
                                " - Cubed ice\n" +
                                " - To garnish: A lemon twist or a maraschino cherry.",
                        "Recipe: \n" +
                                "1. Chill your glass (the easiest way is to fill it with ice)\n" +
                                "2. Add all of the ingredients to a shaker/stirring glass containing plenty of ice and stir gently for around 30 seconds to a minute\n" +
                                "3. Strain the mixture into the glass and garnish with a lemon twist or cherry");
                dao.insert(cocktail);
                // MOJITO
                cocktail = new Cocktail("Mojito", "Rum", "mojito", "Combination of sweetness," +
                        " citrus, and herbaceous mint flavours is intended to complement the rum, and has made the mojito a popular summer drink.",
                        "Ingredients:\n" +
                                " - 2 parts Bacardi Carta Blanca\n" +
                                " - ½ fresh lime\n" +
                                " - 12 fresh mint leaves\n" +
                                " - 2 heaped bar spoons of caster sugar\n" +
                                " - Dash of soda water\n" +
                                " - Cubed and crushed ice\n" +
                                " - To Garnish: Sprig of Fresh Mint\n",
                     /*   "Muddle mint leaves with sugar and lime juice. Add a splash of soda water and fill the glass with cracked ice." +
                                " Pour the rum and top with soda water. Garnish with sprig of mint leaves and lemon slice. Serve with straw.:");        */
                        "Recipe: \n" +
                                "1.  Put the four lime wedges into a glass, add the sugar and muddle to release the lime juice\n" +
                                "2. Put the mint leaves on one hand and clap. Use a muddler or bar spoon to gently push the mint down into the lime juice\n" +
                                "3. Half fill the glass with crushed ice and pour in the Bacardi Carta Blanca. Stir the mix together until the sugar dissolves\n" +
                                "4. Top up with crushed ice, a splash of the soda water and garnish it with a sprig of mint");
                dao.insert(cocktail);
                // PINA COLADA
                cocktail = new Cocktail("Pina Colada", "Rum", "pinacolada",
                        "Pina Colada is a cocktail made with rum, cream of coconut or coconut milk, and pineapple juice," +
                                " usually served either blended or shaken with ice. It may be garnished with either a pineapple wedge, maraschino cherry, or both." +
                                " Pina Colada comes from Puerto Rico.",
                        "Ingredients:\n" +
                                " - 50ml Bacardi Carta Blanco\n" +
                                " - 1 teaspoon sugar\n" +
                                " - 1 part Coconut Cream\n" +
                                " - 6-7 chunks of pineapple\n" +
                                " - 50ml fresh pineapple juice\n" +
                                " - To garnish: A pineapple triangle",
                        "Recipe: \n" +
                                "1. Place all your ingredients into the blender (apart from the garnish) and blend until a smooth consistency\n" +
                                "2. Pour into a chilled (or even better, frozen) glass, then add your garnish and serve");
                dao.insert(cocktail);
            });

            //
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putInt("version", current_version);
            editor.apply();
        }



        mCocktailViewModel = new ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory.getInstance(getApplication())).get(CocktailViewModel.class);

        mCocktailViewModel.getAllCocktails().observe(this, cocktails -> {
            function(cocktails);
            function2(cocktails, 0);
            System.out.println("Proba3: " + strDescription);


        });

        System.out.println("Proba1: " + strDescription);


        btnCocktail1 = (Button) findViewById(R.id.btnCocktail1);
        btnCocktail2 = (Button) findViewById(R.id.btnCocktail2);
        btnCocktail3 = (Button) findViewById(R.id.btnCocktail3);
        btnCocktail4 = (Button) findViewById(R.id.btnCocktail4);
        textCocktailName1 = (TextView) findViewById(R.id.textCocktailName1);
        textCocktailName2 = (TextView) findViewById(R.id.textCocktailName2);
        textCocktailName3 = (TextView) findViewById(R.id.textCocktailName3);
        textCocktailName4 = (TextView) findViewById(R.id.textCocktailName4);

        textCocktailBase1 = (TextView) findViewById(R.id.textCocktailBase1);
        textCocktailBase2 = (TextView) findViewById(R.id.textCocktailBase2);
        textCocktailBase3 = (TextView) findViewById(R.id.textCocktailBase3);
        textCocktailBase4 = (TextView) findViewById(R.id.textCocktailBase4);





        // Stworzenie bazy danych
        CocktailRoomDatabase db = CocktailRoomDatabase.getDatabase(this);

        db.getDatabaseWriteExecutor().execute(() -> {
            CocktailDao cocktailDao = db.cocktailDao();
            System.out.println("TEEEEST_po2");

        });




        // Buttons

        // Cuba Libre
        btnCocktail1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Activity2.class);
                Bundle myDataBundle = new Bundle();
                myDataBundle.putString("picture", cubalibre.get(0));
                myDataBundle.putString("description", cubalibre.get(1));
                myDataBundle.putString("ingredients", cubalibre.get(2));
                myDataBundle.putString("recipe", cubalibre.get(3));

                intent.putExtras(myDataBundle);
                startActivityForResult(intent, 101);
            }
        });

        // Manhattan
        btnCocktail2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Activity2.class);
                Bundle myDataBundle = new Bundle();
                myDataBundle.putString("picture", manhattan.get(0));
                myDataBundle.putString("description", manhattan.get(1));
                myDataBundle.putString("ingredients", manhattan.get(2));
                myDataBundle.putString("recipe", manhattan.get(3));

                intent.putExtras(myDataBundle);
                startActivityForResult(intent, 101);
            }
        });


        // Mojito
        btnCocktail3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Activity2.class);
                Bundle myDataBundle = new Bundle();
                myDataBundle.putString("picture", mojito.get(0));
                myDataBundle.putString("description", mojito.get(1));
                myDataBundle.putString("ingredients", mojito.get(2));
                myDataBundle.putString("recipe", mojito.get(3));

                intent.putExtras(myDataBundle);
                startActivityForResult(intent, 101);
            }
        });

        // Mojito
        btnCocktail4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Activity2.class);
                Bundle myDataBundle = new Bundle();
                myDataBundle.putString("picture", pinacolada.get(0));
                myDataBundle.putString("description", pinacolada.get(1));
                myDataBundle.putString("ingredients", pinacolada.get(2));
                myDataBundle.putString("recipe", pinacolada.get(3));

                intent.putExtras(myDataBundle);
                startActivityForResult(intent, 101);
            }
        });

    } // koniec onCreate



        public void function(List<Cocktail> cocktailList ) {
            // Przypisanie nazw
            if(cocktailList.size()>1) {
                textCocktailName1.setText(cocktailList.get(0).getName());
                textCocktailName2.setText(cocktailList.get(1).getName());
                textCocktailName3.setText(cocktailList.get(2).getName());
                textCocktailName4.setText(cocktailList.get(3).getName());

                textCocktailBase1.setText(cocktailList.get(0).getBase());
                textCocktailBase2.setText(cocktailList.get(1).getBase());
                textCocktailBase3.setText(cocktailList.get(2).getBase());
                textCocktailBase4.setText(cocktailList.get(3).getBase());
            }
        }

        public void function2(List<Cocktail> cocktailList, Integer index ) {

        // Przypisanie nazw
        if(cocktailList.size()>1 && index >=0 ) {


            for(int i=0; i<cocktailList.size(); i++)
            {

                String strLocal = cocktailList.get(i).getPicture();
                strPicture = cocktailList.get(i).getPicture();
                strDescription = cocktailList.get(i).getDescription();
                strIngredients = cocktailList.get(i).getIngredients();
                strRecipe = cocktailList.get(i).getRecipe();

                if(i == 0) {
                    cubalibre.add(strPicture);
                    cubalibre.add(strDescription);
                    cubalibre.add(strIngredients);
                    cubalibre.add(strRecipe);
                }
                System.out.println("Manhattan str1: " + strPicture);
                if(i == 1){
                    System.out.println("Manhattan str2: " + strPicture);
                    System.out.println("Manhattan button: " + manhattan.size());
                    manhattan.add(strPicture);
                    manhattan.add(strDescription);
                    manhattan.add(strIngredients);
                    manhattan.add(strRecipe);
                    System.out.println("Manhattan button: " + manhattan.size());

                }
                if(i == 2) {
                    mojito.add(strPicture);
                    mojito.add(strDescription);
                    mojito.add(strIngredients);
                    mojito.add(strRecipe);
                }
                if(i == 3) {    //  strPicture == "pinacolada"
                    pinacolada.add(strPicture);
                    pinacolada.add(strDescription);
                    pinacolada.add(strIngredients);
                    pinacolada.add(strRecipe);
                }
                else
                    System.out.println("TEST ERROR: ");

            }   // koniec fora
        }   // koniec ifa
    }  // koniec function2

        public void openActivity2() {
            Intent intent = new Intent(this, Activity2.class);
            startActivity(intent);
        }


}   // koniec klasy MainActivity